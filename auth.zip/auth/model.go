package auth

type RegisterRequest struct {
	// 1. Default field
	Phone                string `json:"phone" validate:"required"`
	Password             string `json:"password" validate:"required"`
	CurrentAddress       string `json:"current_address,omitempty"`
	IdentificationNumber string `json:"identification_number,omitempty"`
	FullName             string `json:"full_name,omitempty"`
	DateOfBirth          string `json:"date_of_birth,omitempty"`
	Gender               string `json:"gender,omitempty"`
	Nationality          string `json:"nationality,omitempty"`
	PermanentAddress     string `json:"permanent_address,omitempty"`
	TemporaryAddress     string `json:"temporary_address,omitempty"`

	// 2. Field for customer
	CustomerAccountType string  `json:"account_type"`
	Latitude            float64 `json:"latitude,omitempty"`
	Longtitude          float64 `json:"longtitude,omitempty"`

	// 3. Field for delivery person
}

type LoginRequest struct {
	Phone    string `json:"phone" validate:"required"`
	Password string `json:"password" validate:"required"`
}

type ForgotPasswordRequest struct {
	Phone string `json:"phone" validate:"required"`
}

type ResetPasswordRequest struct {
	Phone           string `json:"phone" validate:"required"`
	NewPassword     string `json:"new_password" validate:"required"`
	ConfirmPassword string `json:"confirm_password" validate:"required"`
}

type UIDRequest struct {
	ID int `json:"id" validate:"required"`
}
